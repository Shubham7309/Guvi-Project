JavaQuizPlatform - Complete Eclipse Dynamic Web Project

Instructions:
1. Import this folder into Eclipse: File -> Import -> Existing Projects into Workspace -> select /mnt/data/JavaQuizPlatform_Complete
2. Ensure Apache Tomcat v9 is configured in Eclipse (Window -> Preferences -> Server -> Runtime Environments).
3. Add MySQL Connector/J jar to project's Build Path or WebContent/WEB-INF/lib.
4. Run schema.sql in MySQL to create the database 'quiz_db'.
5. Update DB credentials in src/dao/DBUtil.java if needed.
6. Run the project on Tomcat (Run As -> Run on Server) and open http://localhost:8080/JavaQuizPlatform/jsp/login.jsp

Included uploaded file path: /mnt/data/70 Live Project Topic - 3rd Sem SCSE- 2028 Passout.pdf
