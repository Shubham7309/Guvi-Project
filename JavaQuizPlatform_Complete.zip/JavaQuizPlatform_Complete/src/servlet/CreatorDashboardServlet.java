package servlet; import model.User; import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException;
@WebServlet("/creatorDashboard") public class CreatorDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session=req.getSession(); User user=(User)session.getAttribute("currentUser"); if(user==null){ resp.sendRedirect("jsp/login.jsp"); return; } req.getRequestDispatcher("jsp/creatorDashboard.jsp").forward(req,resp);
    }
}
