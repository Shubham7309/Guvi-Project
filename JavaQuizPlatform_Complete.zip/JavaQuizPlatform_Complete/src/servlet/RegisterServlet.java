package servlet;
import model.Role; import model.User; import service.UserService;
import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException;
@WebServlet("/register") public class RegisterServlet extends HttpServlet {
    private UserService userService = new UserService();
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name=req.getParameter("name"); String email=req.getParameter("email"); String password=req.getParameter("password"); String roleStr=req.getParameter("role");
        User u=new User(); u.setName(name); u.setEmail(email); u.setPassword(password); u.setRole(Role.valueOf(roleStr));
        try{ userService.register(u); resp.sendRedirect("jsp/login.jsp?msg=Registered+successfully"); } catch(SQLException e){ throw new ServletException(e); }
    }
}
