package model;
import java.util.List;
public class Quiz {
    private int quizId; private String title; private String description; private int durationMin; private int createdBy; private boolean active; private List<Question> questions;
    public int getQuizId(){return quizId;} public void setQuizId(int id){this.quizId=id;}
    public String getTitle(){return title;} public void setTitle(String t){this.title=t;}
    public String getDescription(){return description;} public void setDescription(String d){this.description=d;}
    public int getDurationMin(){return durationMin;} public void setDurationMin(int m){this.durationMin=m;}
    public int getCreatedBy(){return createdBy;} public void setCreatedBy(int c){this.createdBy=c;}
    public boolean isActive(){return active;} public void setActive(boolean a){this.active=a;}
    public List<Question> getQuestions(){return questions;} public void setQuestions(List<Question> q){this.questions=q;}
}
