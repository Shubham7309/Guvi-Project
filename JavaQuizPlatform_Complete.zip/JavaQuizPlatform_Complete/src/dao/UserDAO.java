package dao;
import model.Role; import model.User;
import java.sql.*;
public class UserDAO {
    public void register(User user) throws SQLException {
        String sql = "INSERT INTO users(name, email, password, role) VALUES(?,?,?,?)";
        try (Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){
            ps.setString(1,user.getName()); ps.setString(2,user.getEmail()); ps.setString(3,user.getPassword()); ps.setString(4,user.getRole().name()); ps.executeUpdate();
        }
    }
    public User findByEmailAndPassword(String email, String password) throws SQLException {
        String sql="SELECT * FROM users WHERE email=? AND password=?";
        try (Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){
            ps.setString(1,email); ps.setString(2,password);
            try (ResultSet rs=ps.executeQuery()){ if(rs.next()){ User u=new User(); u.setUserId(rs.getInt("user_id")); u.setName(rs.getString("name")); u.setEmail(rs.getString("email")); u.setPassword(rs.getString("password")); u.setRole(Role.valueOf(rs.getString("role"))); return u; } }
        }
        return null;
    }
}
